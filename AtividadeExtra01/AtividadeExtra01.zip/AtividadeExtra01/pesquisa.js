function iniciarPesquisa() {
    let somaIdades = 0;
    let maiorIdade = 0;
    let menorIdade = 0;
    let quantidadePessimo = 0;
    let quantidadeOtimoBom = 0;
    let mulheres = 0;
    let homens = 0;
    let outros = 0;

    for (let i = 1; i <= 45; i++) {
        let idade = parseInt(prompt("Pessoa " + i + " de 45 - Digite a idade:"));

        while (isNaN(idade) || idade < 0) {
            idade = parseInt(prompt("Idade inválida. Digite novamente:"));
        }

        let sexo = prompt("Pessoa " + i + " - Sexo (feminino, masculino ou outros):");
        sexo = sexo.toLowerCase().trim();

        while (sexo != "feminino" && sexo != "masculino" && sexo != "outros") {
            sexo = prompt("Opção inválida. Digite feminino, masculino ou outros:");
            if (sexo == null) {
                sexo = "";
            } else {
                sexo = sexo.toLowerCase().trim();
            }
        }

        let opiniao = parseInt(prompt(
            "Pessoa " + i + " - Opinião:\n4 = Ótimo\n3 = Bom\n2 = Regular\n1 = Péssimo"
        ));

        while (isNaN(opiniao) || opiniao < 1 || opiniao > 4) {
            opiniao = parseInt(prompt("Digite 1, 2, 3 ou 4 para a opinião:"));
        }

        somaIdades = somaIdades + idade;

        if (i == 1 || idade > maiorIdade) {
            maiorIdade = idade;
        }

        if (i == 1 || idade < menorIdade) {
            menorIdade = idade;
        }

        if (opiniao == 1) {
            quantidadePessimo++;
        }

        if (opiniao == 3 || opiniao == 4) {
            quantidadeOtimoBom++;
        }

        if (sexo == "feminino") {
            mulheres++;
        } else if (sexo == "masculino") {
            homens++;
        } else {
            outros++;
        }
    }

    let mediaIdade = somaIdades / 45;
    let porcentagemOtimoBom = (quantidadeOtimoBom / 45) * 100;

    document.getElementById("resultado").innerHTML =
        "<h2>Resultado da pesquisa</h2>" +
        "<p>Média das idades: " + mediaIdade.toFixed(2) + "</p>" +
        "<p>Maior idade: " + maiorIdade + "</p>" +
        "<p>Menor idade: " + menorIdade + "</p>" +
        "<p>Respostas péssimo: " + quantidadePessimo + "</p>" +
        "<p>Porcentagem de ótimo e bom: " + porcentagemOtimoBom.toFixed(2) + "%</p>" +
        "<p>Mulheres: " + mulheres + "</p>" +
        "<p>Homens: " + homens + "</p>" +
        "<p>Outros: " + outros + "</p>";
}
