function criarFuncionarios() {

    // 1ª forma: utilizando new Object()
    let Funcionario1 = new Object();
    Funcionario1.Matricula = "001";
    Funcionario1.Nome = "Carlos";
    Funcionario1.Funcao = "Analista";

    // 2ª forma: utilizando chaves vazias {}
    let Funcionario2 = {};
    Funcionario2.Matricula = "002";
    Funcionario2.Nome = "Mariana";
    Funcionario2.Funcao = "Desenvolvedora";

    // 3ª forma: criando o objeto de forma literal
    let Funcionario3 = {
        Matricula: "003",
        Nome: "João",
        Funcao: "Técnico de Suporte"
    };

    // Mostrando as propriedades dos três objetos
    document.getElementById("resultado").innerHTML =
        "<h2>1ª forma: new Object()</h2>" +
        "<p>Matrícula: " + Funcionario1.Matricula + "</p>" +
        "<p>Nome: " + Funcionario1.Nome + "</p>" +
        "<p>Função: " + Funcionario1.Funcao + "</p>" +

        "<h2>2ª forma: {}</h2>" +
        "<p>Matrícula: " + Funcionario2.Matricula + "</p>" +
        "<p>Nome: " + Funcionario2.Nome + "</p>" +
        "<p>Função: " + Funcionario2.Funcao + "</p>" +

        "<h2>3ª forma: objeto literal</h2>" +
        "<p>Matrícula: " + Funcionario3.Matricula + "</p>" +
        "<p>Nome: " + Funcionario3.Nome + "</p>" +
        "<p>Função: " + Funcionario3.Funcao + "</p>";
}
