// 1. Recebe três números e retorna o maior deles.
function maiorDeTres(n1, n2, n3) {
    if (isNaN(n1) || isNaN(n2) || isNaN(n3)) {
        return "Digite os três números.";
    }

    return "O maior número é: " + Math.max(n1, n2, n3);
}


// 2. Recebe três números e retorna em ordem crescente.
function ordemCrescente(n1, n2, n3) {
    if (isNaN(n1) || isNaN(n2) || isNaN(n3)) {
        return "Digite os três números.";
    }

    let numeros = [n1, n2, n3];
    numeros.sort(function(a, b) {
        return a - b;
    });

    return "Ordem crescente: " + numeros.join(", ");
}


// 3. Recebe uma string e verifica se ela é palíndromo.
function verificarPalindromo(texto) {
    let palavra = texto.toLowerCase().replace(/\s/g, "");
    let invertida = palavra.split("").reverse().join("");

    if (palavra == "") {
        return "Digite uma palavra ou frase.";
    }

    if (palavra == invertida) {
        return "É um palíndromo.";
    } else {
        return "Não é um palíndromo.";
    }
}


// 4. Verifica se a segunda palavra está contida na primeira.
function verificarSubconjunto(palavra1, palavra2) {
    if (palavra1 == undefined || palavra2 == undefined ||
        palavra1.trim() == "" || palavra2.trim() == "") {
        return "Erro: uma ou as duas palavras estão vazias.";
    }

    palavra1 = palavra1.toLowerCase();
    palavra2 = palavra2.toLowerCase();

    if (palavra1.indexOf(palavra2) != -1) {
        return "É um subconjunto.";
    } else {
        return "Não é um subconjunto.";
    }
}


// 5. Recebe uma data e retorna o dia da semana.
function diaDaSemana(data) {
    if (data == "") {
        return "Selecione uma data.";
    }

    let partes = data.split("-");
    let ano = parseInt(partes[0]);
    let mes = parseInt(partes[1]);
    let dia = parseInt(partes[2]);

    let dataInformada = new Date(ano, mes - 1, dia);

    let dias = [
        "Domingo", "Segunda-feira", "Terça-feira", "Quarta-feira",
        "Quinta-feira", "Sexta-feira", "Sábado"
    ];

    return "O dia da semana é: " + dias[dataInformada.getDay()];
}
