function calcularIMC() {
    let altura = parseFloat(document.getElementById("altura").value);
    let peso = parseFloat(document.getElementById("peso").value);

    if (isNaN(altura) || isNaN(peso) || altura <= 0 || peso <= 0) {
        alert("Digite uma altura e um peso válidos.");
        return;
    }

    let imc = peso / (altura * altura);
    let classificacao;
    let obesidade;

    if (imc < 18.5) {
        classificacao = "Magreza";
        obesidade = "0";
    } else if (imc < 25) {
        classificacao = "Normal";
        obesidade = "0";
    } else if (imc < 30) {
        classificacao = "Sobrepeso";
        obesidade = "I";
    } else if (imc < 40) {
        classificacao = "Obesidade";
        obesidade = "II";
    } else {
        classificacao = "Obesidade grave";
        obesidade = "III";
    }

    document.getElementById("resultado").innerHTML =
        "<h2>Resultado</h2>" +
        "<p>IMC: " + imc.toFixed(2) + "</p>" +
        "<p>Classificação: " + classificacao + "</p>" +
        "<p>Obesidade (grau): " + obesidade + "</p>";
}
