let jogador = prompt("Escolha: pedra, papel ou tesoura").toLowerCase();

let numero = Math.floor(Math.random() * 3);
let computador;

if (numero == 0) {
    computador = "pedra";
} else if (numero == 1) {
    computador = "papel";
} else {
    computador = "tesoura";
}

let resultado;

if (jogador == computador) {
    resultado = "Empate!";
} else if (
    (jogador == "pedra" && computador == "tesoura") ||
    (jogador == "tesoura" && computador == "papel") ||
    (jogador == "papel" && computador == "pedra")
) {
    resultado = "Você venceu!";
} else if (
    jogador == "pedra" ||jogador == "papel" ||jogador == "tesoura"
) {
    resultado = "O computador venceu!";
} else {
    resultado = "Escolha inválida!";
}

alert(
    "Você escolheu: " + jogador +
    "\nComputador escolheu: " + computador +
    "\nResultado: " + resultado
);