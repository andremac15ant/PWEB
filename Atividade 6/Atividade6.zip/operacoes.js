let numero1 = parseFloat(prompt("Digite o primeiro número:"));
let numero2 = parseFloat(prompt("Digite o segundo número:"));

let confirmar = confirm("Deseja realizar as operações com os números informados?");

if (confirmar) {
    let soma = numero1 + numero2;
    let subtracao = numero1 - numero2;
    let produto = numero1 * numero2;

    if (numero2 !== 0) {
        let divisao = numero1 / numero2;
        let resto = numero1 % numero2;

        alert(
            "Soma: " + soma +
            "\nSubtração: " + subtracao +
            "\nProduto: " + produto +
            "\nDivisão: " + divisao +
            "\nResto: " + resto
        );
    } else {
        alert(
            "Soma: " + soma +
            "\nSubtração: " + subtracao +
            "\nProduto: " + produto +
            "\nDivisão e resto não podem ser calculados com o segundo número igual a zero."
        );
    }
} else {
    alert("Operações canceladas.");
}
